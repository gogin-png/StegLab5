with open("price_M.txt") as f:
    text = f.read()
new_text = ""
for c in text:
    if (c >= 'A' and c <= 'Z') or (c >= 'a' and c <= 'z') or (c == ' '):
        new_text += c
with open("price_purchase.txt", 'w') as f:
     text = print(new_text, file=f)

with open("price_purchase.txt") as f:
    words = f.read().replace('\n', ' ').split(' ')

words_count = dict.fromkeys(set(words), 0)
for w in words:
    words_count[w] += 1

words_sorted = sorted(words_count.items(), key=lambda item: (-item[1], item[0]))

with open("price.txt", 'w') as f:
    for p in words_sorted:
        print(p[0], end=" ", file=f)

    # for p in words_sorted:
    #     print(p[0], end=" ")