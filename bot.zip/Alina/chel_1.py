import requests
import time
import pyautogui
from datetime import datetime



variable_sales = 0
#time.sleep(10)
while True:

    if variable_sales == 1:
        variable_sales = variable_sales - 1

    time_start = time.time()

    time.sleep(1)

    txt_1 = str(1)
    txt_2 = str(111111111)
    txt_3 = str(0)
    txt_4 = str(1)

    file = open("price.txt", "w")
    file.write(txt_1)
    file.close()

    file = open("price_m.txt", "w")
    file.write(txt_2)
    file.close()

    file = open("price_purchase.txt", "w")
    file.write(txt_3)
    file.close()

    file = open("max_price_after_purchase.txt", "w")
    file.write(txt_4)
    file.close()

    # variable_sales = 0

    def distribution_of_support(arg_2):
        per_2 = (max(arg_2)-min(arg_2))/100
        return per_2

    def percent(arg):# выводит % раздницу между значение txt и BTC
        per = ((max(arg) / min(arg)) - 1)
        return per

    def price_BTC():
        url = "https://api.binance.com/api/v3/ticker/price"
        data = requests.get(url)
        data.raise_for_status()
        data_1 = data.json()
        st = (next(x for x in data_1 if x["symbol"] == "BTCBUSD"))
        price_1 = (st.get('price'))
        sp = []
        sp.append(price_1)
        cr = float(sp[0])
        return cr

    pyautogui.PAUSE = 1
    pyautogui.FAILSAFE = True

    pyautogui.size()
    pyautogui.position()

    while variable_sales < 1:

        time_start = time.time()

        now = datetime.now()
        current_time = now.strftime("%H:%M:%S")

        time.sleep(1)
        p = price_BTC() # сравнивает значение в price_txt и входящее из BTC

        file = open("price.txt", "r")
        c = file.read()
        s = float(c)
        # print(type(s))
        # print(type(p))
        # file_purchase = open("price_purchase.txt", "r")
        # lz = file_purchase.read()
        # purchase = float(lz)

        if p >= s: # записывает наибольшее значение в price.txt
            cur_time = time.time()
            #print('cur_time = ', cur_time)
            b = str(p)
            file_1 = open("price.txt", "w")
            file_1.write(b)
            file_1.close()
            #print("больше")

        arg = p, s
        print('Падение цены =', percent(arg))

        file_2 = open("price_M.txt", "r")  # извлекает значение price_M
        m = file_2.read()
        k = float(m)

        if percent(arg) >= 0.003: #падение цены


            file_2 = open("price_M.txt", "r") #извлекает значение price_M
            m = file_2.read()
            k = float(m)

            cur_time_2 = time.time()
            print('cur_time_2 = ', cur_time_2)

            if p < k and p < s and cur_time - cur_time_2 < 0: #заносит наименьшее значение в фаил
                z = str(p)
                file_3 = open("price_M.txt", "w")
                file_3.write(z)
                file_3.close()

            else:
                print("нет покупки", "Current Time =", current_time)

            arg_2 = k, p

            file = open("price.txt", "r")
            c_2 = file.read()
            print(c_2)
            maximumi = float(c_2)

            the_difference_between_max_min = (maximumi - k)*0.1 # извлекает 10% от разности max и min значения
            price_dif = p - k

            # print('hof =', price_dif)
            # print('proz_pric_fx =', the_difference_between_max_min)
            if price_dif >= the_difference_between_max_min and p > k: # запоминает значение покупки!!!!!!!!!!!!!!!!!!!! ПРОВЕРИТЬ
                p_2 = str(p)
                file_purchase = open("price_purchase.txt", "w")
                file_purchase.write(p_2)
                file_purchase.close()

                pyautogui.moveTo(935, 465, duration=0.1) # левый скрол
                pyautogui.click(clicks=1)
                pyautogui.moveTo(750, 600, duration=0.1) # покупка левая кнопка
                pyautogui.click(clicks=1)

                pi = 0

                while variable_sales < 1:

                    p = price_BTC()

                    now = datetime.now()
                    current_time = now.strftime("%H:%M:%S")

                    time.sleep(0.5)

                    file_4 = open("max_price_after_purchase.txt", "r")
                    cf = file_4.read()
                    sf = float(cf)

                    print('максимальная цена после покупки =', sf, "Current Time =", current_time)

                    file_5 = open("price_purchase.txt", "r")
                    cf_1 = file_5.read()
                    sf_1 = float(cf)

                    print('цена покупки =', sf_1, "Current Time =", current_time)
                    print('#' * 60)

                    if p >= sf:
                        bf = str(p)
                        file_6 = open("max_price_after_purchase.txt", "w")  #ищит максимальную цену после покупки
                        file_6.write(bf)
                        file_6.close()

                    time.sleep(30)

                    if p < sf_1:

                        pyautogui.moveTo(1485, 465, duration=0.1)  # правый ползунок
                        pyautogui.click(clicks=1)
                        pyautogui.moveTo(1150, 600, duration=0.1)  # прая кнопка продажи
                        pyautogui.click(clicks=1)

                        file_5 = open("price_purchase.txt", "r")
                        cf_1 = file_5.read()
                        sf_1 = float(cf)
                        p = price_BTC()

                        print("ПРОДАЖА цена меньше p=", p, "Цена покупки =", sf_1)
                        print('#' * 60)

                        zx = str(p - sf_1)
                        print(zx)

                        while True:

                            p = price_BTC()
                            file_11 = open("price_purchase.txt", "r")
                            cf_1 = file_11.read()
                            sf_1 = float(cf)

                            if p >= sf_1:

                                pyautogui.moveTo(935, 465, duration=0.1)  # левый скрол
                                pyautogui.click(clicks=1)
                                pyautogui.moveTo(750, 600, duration=0.1)  # покупка левая кнопка
                                pyautogui.click(clicks=1)

                                break
                            else:
                                print("Цена меньше покупки")

                    max_price_after_purchase_1 = open("max_price_after_purchase.txt", "r")  # извлекает значение max_price_after_purchase.txt
                    m_max_price_after_purchase = max_price_after_purchase_1.read()
                    k_max_price_after_purchase = float(m_max_price_after_purchase)

                    file_price_purchase = open("price_purchase.txt", "r")#извлекает значение price_purchase.txt цена покупки
                    price_purchase_1 = file_price_purchase.read()
                    price_purchase_1f = float(price_purchase_1)

                    growth_purchase = (k_max_price_after_purchase - price_purchase_1f)*0.3 # 30% от цены роста после покупки

                    the_price_of_falling = k_max_price_after_purchase - p

                    print('цена приемлема', "Current Time =", current_time)

                    if the_price_of_falling > growth_purchase:

                        pyautogui.moveTo(1485, 465, duration=0.1)# правый ползунок
                        pyautogui.click(clicks=1)
                        pyautogui.moveTo(1150, 600, duration=0.1)# прая кнопка продажи
                        pyautogui.click(clicks=1)

                        file_5 = open("price_purchase.txt", "r")
                        cf_1 = file_5.read()
                        sf_1 = float(cf)
                        p = price_BTC()

                        print("#продажа =", p, "Цена покупки =", sf_1, "#")

                        zx = str(p - sf_1)
                        print(zx)


                        variable_sales = variable_sales + 1

        else:
            print("ждём", p, "Current Time =", current_time,"price.txt =", s , "price_M =", k,)
            print('#' * 60)