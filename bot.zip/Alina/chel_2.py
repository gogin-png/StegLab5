import time

print(type(time.time()))
while True:
    a = time.time()
    time.sleep(5)

    t = a - time.time()
    print(t)
    print(type(t))


